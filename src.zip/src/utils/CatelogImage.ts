
import dress1 from "../assets/dress/01.png";
import dress2 from "../assets/dress/02.png";
import dress3 from "../assets/dress/03.png";
import dress4 from "../assets/dress/04.png";
import dress5 from "../assets/dress/05.png";
import dress6 from "../assets/dress/06.png";
import dress7 from "../assets/dress/07.png";
import dress8 from "../assets/dress/08.png";
import dress9 from "../assets/dress/09.png";
import dress10 from "../assets/dress/10.png";
import dress11 from "../assets/dress/11.png";
import dress12 from "../assets/dress/12.png";
import dress13 from "../assets/dress/13.png";
import dress14 from "../assets/dress/14.png";
import dress15 from "../assets/dress/15.png";
import dress16 from "../assets/dress/16.png";
import dress17 from "../assets/dress/17.png";
import dress18 from "../assets/dress/18.png";





const data = [
  {
    _id: 1,
    image: dress1,
  },
  {
    _id: 2,
    image: dress2,
  },
  {
    _id: 3,
    image: dress3,
  },
  {
    _id: 4,
    image: dress4,
  },
  {
    _id: 5,
    image: dress5,
  },
  {
    _id: 6,
    image: dress6,
  },
  {
    _id: 7,
    image: dress7,
  },
  {
    _id: 8,
    image: dress8,
  },
  {
    _id: 9,
    image: dress9,
  },
  {
    _id: 10,
    image: dress10,
  },
  {
    _id: 11,
    image: dress11,
  },
  {
    _id: 12,
    image: dress12,
  }, {
    _id: 13,
    image: dress13,
  }, {
    _id: 14,
    image: dress14,
  }, {
    _id: 15,
    image: dress15,
  }, {
    _id: 16,
    image: dress16,
  },
  {
    _id: 17,
    image: dress17,
  },{
    _id: 18,
    image: dress18,
  },
];

  export default data