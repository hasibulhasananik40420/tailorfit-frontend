// filterSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface FilterState {
  all: boolean;
  orderDate: boolean;
  trialDate: boolean;
  deliveryDate: boolean;
  workerDate: boolean;
  
}

const initialState: FilterState = {
  all: false,
  orderDate: false,
  trialDate: false,
  deliveryDate: false,
  workerDate: false,
};

const filterDateSlice = createSlice({
  name: 'filterDate',
  initialState,
  reducers: {
    setAll(state, action: PayloadAction<boolean>) {
      const value = action.payload;
      state.all = value;
      state.orderDate = value;
      state.trialDate = value;
      state.deliveryDate = value;
      state.workerDate = value;
      
    },
    toggleOrderDate(state) {
      state.orderDate = !state.orderDate;
    },
    toggleTrialDate(state) {
      state.trialDate = !state.trialDate;
    },
    toggleDeliveryDate(state) {
      state.deliveryDate = !state.deliveryDate;
    },
    toggleWorkerDate(state) {
      state.workerDate = !state.workerDate;
    },
   
  },
});

export const {
  setAll,
  toggleOrderDate,
  toggleTrialDate,
  toggleDeliveryDate,
  toggleWorkerDate,
  
} = filterDateSlice.actions;

export default filterDateSlice.reducer;
