export enum tagTypes {
    updateProfile ='updateProfile',
    admin='admin',
    user='user',
    createCostumer ='createCostumer',
    industryName ='industryName',
    createMeasurement ='createMeasurement',
    createGallary ='createGallary',
    createSetting ='createSetting',
    individualOrder='individualOrder',
    companyOders='companyOders',
    companyFolderDelete='companyFolderDelete',
    userLogout='userLogout'
   
    
   

}


export const tagTypesList =[
    tagTypes.updateProfile,
    tagTypes.admin,
    tagTypes.createCostumer,
    tagTypes.createMeasurement,
    tagTypes.createGallary,
    tagTypes.createSetting,
    tagTypes.individualOrder,
    tagTypes.companyOders,
    tagTypes.companyFolderDelete,
    tagTypes.userLogout,

   
   
]